
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

let bookings = []; // In-memory storage for simplicity

// Create a booking
app.post('/api/bookings', (req, res) => {
    const { date, time, guests, name, contact } = req.body;

    if (!date || !time || !guests || !name || !contact) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    const bookingExists = bookings.some(
        (b) => b.date === date && b.time === time
    );

    if (bookingExists) {
        return res.status(400).json({ error: 'Time slot already booked.' });
    }

    const booking = { id: bookings.length + 1, date, time, guests, name, contact };
    bookings.push(booking);
    res.status(201).json(booking);
});

// Get all bookings
app.get('/api/bookings', (req, res) => {
    res.json(bookings);
});

// Delete a booking
app.delete('/api/bookings/:id', (req, res) => {
    const { id } = req.params;
    bookings = bookings.filter((b) => b.id !== parseInt(id, 10));
    res.status(200).json({ message: 'Booking deleted successfully.' });
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Backend server running on http://localhost:${PORT}`);
});
