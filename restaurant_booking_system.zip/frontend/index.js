
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const Home = () => {
    const [date, setDate] = useState(new Date());
    const [time, setTime] = useState('12:00');
    const [guests, setGuests] = useState(1);
    const [name, setName] = useState('');
    const [contact, setContact] = useState('');
    const [bookings, setBookings] = useState([]);
    const [message, setMessage] = useState('');

    useEffect(() => {
        axios.get('http://localhost:5000/api/bookings')
            .then((response) => setBookings(response.data))
            .catch((error) => console.error(error));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        axios.post('http://localhost:5000/api/bookings', {
            date: date.toISOString().split('T')[0],
            time,
            guests,
            name,
            contact
        }).then((response) => {
            setMessage('Booking successful!');
            setBookings([...bookings, response.data]);
        }).catch((error) => {
            setMessage(error.response?.data?.error || 'Something went wrong.');
        });
    };

    return (
        <div>
            <h1>Restaurant Table Booking</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Date:</label>
                    <DatePicker selected={date} onChange={(date) => setDate(date)} />
                </div>
                <div>
                    <label>Time:</label>
                    <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
                </div>
                <div>
                    <label>Number of Guests:</label>
                    <input type="number" value={guests} onChange={(e) => setGuests(e.target.value)} />
                </div>
                <div>
                    <label>Name:</label>
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div>
                    <label>Contact:</label>
                    <input type="text" value={contact} onChange={(e) => setContact(e.target.value)} />
                </div>
                <button type="submit">Book</button>
            </form>
            {message && <p>{message}</p>}
            <h2>Bookings</h2>
            <ul>
                {bookings.map((b) => (
                    <li key={b.id}>{b.date} {b.time} - {b.name} ({b.guests} guests)</li>
                ))}
            </ul>
        </div>
    );
};

export default Home;
