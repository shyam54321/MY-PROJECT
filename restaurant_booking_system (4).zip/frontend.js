
// Next.js (Frontend)
import { useState, useEffect } from 'react';
import axios from 'axios';

const BookingForm = () => {
  const [formData, setFormData] = useState({
    date: '',
    time: '',
    guests: '',
    name: '',
    contact: ''
  });
  const [availableSlots, setAvailableSlots] = useState([]);
  const [bookingSummary, setBookingSummary] = useState(null);
  const [calendarView, setCalendarView] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const fetchAvailableSlots = async () => {
    try {
      const response = await axios.get(`/api/bookings/available`, {
        params: { date: formData.date, time: formData.time }
      });
      setAvailableSlots(response.data.slots);
    } catch (error) {
      console.error('Error fetching available slots:', error);
    }
  };

  useEffect(() => {
    if (formData.date && formData.time) {
      fetchAvailableSlots();
    }
  }, [formData.date, formData.time]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/bookings', formData);
      setBookingSummary(response.data);
    } catch (error) {
      console.error('Error creating booking:', error);
    }
  };

  return (
    <div>
      {!bookingSummary ? (
        <div>
          <button onClick={() => setCalendarView(!calendarView)}>
            {calendarView ? 'Switch to Form View' : 'Switch to Calendar View'}
          </button>
          {calendarView ? (
            <div>
              {/* Simple Calendar or Timeline View Implementation */}
              <h2>Calendar View</h2>
              <ul>
                {availableSlots.map((slot, index) => (
                  <li key={index}>
                    <button onClick={() => setFormData({ ...formData, time: slot })}>{slot}</button>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div>
                <label>Date:</label>
                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <label>Time:</label>
                <input
                  type="time"
                  name="time"
                  value={formData.time}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <label>Guests:</label>
                <input
                  type="number"
                  name="guests"
                  value={formData.guests}
                  onChange={handleInputChange}
                  min="1"
                  required
                />
              </div>
              <div>
                <label>Name:</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <label>Contact:</label>
                <input
                  type="text"
                  name="contact"
                  value={formData.contact}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <button type="submit">Book Now</button>
            </form>
          )}
        </div>
      ) : (
        <div>
          <h2>Booking Confirmation</h2>
          <p>Date: {bookingSummary.date}</p>
          <p>Time: {bookingSummary.time}</p>
          <p>Guests: {bookingSummary.guests}</p>
          <p>Name: {bookingSummary.name}</p>
          <p>Contact: {bookingSummary.contact}</p>
        </div>
      )}
    </div>
  );
};

export default BookingForm;
