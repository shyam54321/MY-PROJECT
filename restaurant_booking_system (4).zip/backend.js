
// Node.js (Backend)
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());

let bookings = [];

// Get available slots
app.get('/api/bookings/available', (req, res) => {
  const { date, time } = req.query;
  const unavailableSlots = bookings.filter(
    (booking) => booking.date === date && booking.time === time
  );

  const slots = Array.from({ length: 24 }, (_, i) => `${i}:00`).filter(
    (slot) => !unavailableSlots.some((booking) => booking.time === slot)
  );

  res.json({ slots });
});

// Create booking
app.post('/api/bookings', (req, res) => {
  const { date, time, guests, name, contact } = req.body;

  if (!date || !time || !guests || !name || !contact) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  const isSlotTaken = bookings.some(
    (booking) => booking.date === date && booking.time === time
  );

  if (isSlotTaken) {
    return res.status(400).json({ message: 'Slot is already booked.' });
  }

  const newBooking = { date, time, guests, name, contact };
  bookings.push(newBooking);

  res.status(201).json(newBooking);
});

// Delete booking
app.delete('/api/bookings/:id', (req, res) => {
  const { id } = req.params;
  bookings = bookings.filter((_, index) => index !== parseInt(id));
  res.status(200).json({ message: 'Booking deleted successfully.' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
